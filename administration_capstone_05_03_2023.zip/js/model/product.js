
function product (_idProduc,_name,_price,_screen,_blackCamera,_frontCamera,_img,_category,_description) {
    this.id = _idProduc
    this.name = _name
    this.price = _price
    this.screen = _screen
    this.backCamera = _blackCamera
    this.frontCamera = _frontCamera
    this.img = _img
    this.category = _category
    this.description = _description
}